import { RepoMetadata } from "@mochiapp/js";

let metadata: RepoMetadata = {
    name: "Inu's Modules",
    author: "Inumaki"
}

export default metadata;