# Mochi Repository

### Usage
Use your favorite package manager and run:
```bash
npm install
```